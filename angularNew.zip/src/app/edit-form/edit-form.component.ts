import { Component, EventEmitter, Input, OnChanges, OnInit, Output } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { CompoundService } from '../services/compound.service';
declare var $: any

@Component({
  selector: 'app-edit-form',
  templateUrl: './edit-form.component.html',
  styleUrls: ['./edit-form.component.css']
})
export class EditFormComponent implements OnInit, OnChanges {

  public editDet!: FormGroup;
  public submitted: boolean = false;
  @Input() selCom: any;
  @Output() updateDets = new EventEmitter<any>();

  constructor(
    private fb: FormBuilder,
    private comService: CompoundService
  ) {
    this.editDet = this.fb.group({
      compoundName: [''],
      compoundDescription: [''],
      // year: [''],
      // price: ['']
    })
  }

  ngOnInit(): void {
  }

  ngOnChanges() {
    // debugger;
    if (this.selCom) this.populateDets();
  }

  populateDets() {
    // debugger;
    if (this.selCom) {
      console.log(this.selCom)
      this.editDet.patchValue(this.selCom)
    }
  }

  editComp() {
    // debugger;
    let payload = {
      UUID: this.selCom?.UUID,
      compoundName: this.editDet.value.compoundName,
      compoundDescription: this.editDet.value.compoundDescription,
      strImageSource: this.selCom?.strImageSource,
      strImageAttribution: this.selCom?.strImageAttribution,
      // dateModified: this.editDet.value.UUID,
    }
    this.comService.editCompound(this.selCom?.Id, payload).subscribe((res: any)=>{
      if(res?.statusCode == 200){
        alert("Compound Updated Successfully")
        this.updateDets.emit()
      }else{
        alert("Error")
      }
    })
  }

  get validate() {
    return this.editDet.controls
  }

  closeEdit() {
    this.submitted = false
    // this.fillEdit()
    $("#editusersmodal").modal("hide")
  }

}
