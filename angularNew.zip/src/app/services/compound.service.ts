import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class CompoundService {

  constructor( private http: HttpClient) { }

  getCompounds(){
    return this.http.get("http://localhost:3000/api/v1/compound/getAll")
  }

  editCompound(id: any, body: any){
    return this.http.put("http://localhost:3000/api/v1/compound/update?id=" + id, body)
  }
}
