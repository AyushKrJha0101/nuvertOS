import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EditFormComponent } from './edit-form/edit-form.component';
import { MainComponent } from './main/main.component';

const routes: Routes = [
  {path:"",component:MainComponent},
  {path:"dashboard",component:MainComponent},
  {path:"login",component:EditFormComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
