import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CompoundService } from '../services/compound.service';
declare var $:any

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {

  public arr: any = []
  public searchArr: any = []

  constructor(
    private router: Router,
    private comService: CompoundService
  ) { }

  ngOnInit(): void {
    this.getCompounds();
  }

  openAdd(){
    $("#editusersmodal").modal("show")
  }

  selectedCompound: any
  openEdit(info: any, ind: any){
    this.selectedCompound = info
    $("#editusersmodal").modal("show")
  }

  openInfo(info: any){
    this.selectedCompound = info
    setTimeout(() => {
      $("#infomodal").modal("show")
    },200)
  }

  compoundsData: any[] = [];
  getCompounds(){
    this.comService.getCompounds().subscribe((res: any)=>{
      if(res?.statusCode == "200"){
        this.compoundsData = res?.data;
        console.log(this.compoundsData)
      }
    })
  }

  // $scope.showPopover = function() {
  //   $scope.popoverIsVisible = true; 
  // };

  showPopover(){
    console.log("WORKING");
    
    $('#info').style.display = 'block';
  }
  
  // $scope.hidePopover = function () {
  //   $scope.popoverIsVisible = false;
  // };

}
