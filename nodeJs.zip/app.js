let path = require("path");
let fixture = path.join(__dirname, "./.env");
let dotenv = require('dotenv').config({ path: fixture })
let config = dotenv.parsed
const request = require("request");
const express = require("express");
const app = express();
var bodyParser = require('body-parser');

// app.set("view engine", "ejs");
const cors = require("cors");
// middleware for retriving request body
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
//cors
var whiteList = config.WHITELIST;
console.log(whiteList)
var corsOptionsDelegate = function (req, callback) {
    var corsOptions;
    if (whiteList.indexOf(req.header("Origin")) !== -1) {
        corsOptions = { origin: true };
    } else {
        corsOptions = { origin: false };
    }
    callback(null, corsOptions);
};
app.use(cors(corsOptionsDelegate));
 
let compound = require("./routes/compound");
app.use("/api/v1/compound", compound);


app.use("/uploads", express.static(path.join(__dirname, "uploads")));

const PORT = process.env.PORT
app.listen(PORT, process.env.HOST, () => {
    console.log(`server is running on port ${PORT}`);
});
