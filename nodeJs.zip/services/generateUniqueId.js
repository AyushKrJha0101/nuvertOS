const { customAlphabet } = require('nanoid')



const nanoidUnique = customAlphabet("1234567890abcdefghijklmnopqrstuvwxyz", 15)


let genrateUUI = () => {
    return nanoidUnique();
}

module.exports = {
    genrateUUI
}