const multer = require("multer");
var path = require("path");
const storage = multer.diskStorage({
  destination: (req, file, callback) => {
    callback(null, "./uploads/");
  },

  filename: (req, file, callback) => {
    let hours = new Date().getHours();
    let minutes = new Date().getMinutes();
    let seconds = new Date().getSeconds();
    let fileName = file.originalname;
    if (fileName.includes("&")) {
      fileName = fileName.replace("&", "-and-");
    }

    callback(null, String(fileName.split(".")[0]).replace(/[\])}[{(]/g, "") + "-" + hours + "-" + minutes + "-" + seconds + path.extname(fileName));
  },
});
const upload = multer({
  storage: storage,
  limits: {
    fileSize: 1024 * 1024 * 50,
  },
});
module.exports = { upload };
