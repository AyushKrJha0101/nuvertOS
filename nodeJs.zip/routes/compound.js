const compound = require("../controllers/compound");
const routes = require("express").Router();
const { upload } = require("../services/uploadMiddleware")

routes.post("/importSpreadsheet", upload.single("file"), compound.importspreadsheet)

routes.put("/update", compound.update)

routes.get("/getAll", compound.getAll)

module.exports = routes