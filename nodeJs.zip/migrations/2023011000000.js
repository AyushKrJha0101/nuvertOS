"use strict";
module.exports = {
    async up(queryInterface, Sequelize) {
        await queryInterface.createTable("compound", {
            Id: { type: Sequelize.STRING(15), allowNull: false, primaryKey: true },
            UUID: { type: Sequelize.INTEGER },
            compoundName: { type: Sequelize.STRING(50) },
            compoundDescription: { type: Sequelize.STRING(300) },
            strImageSource: { type: Sequelize.STRING(100), },
            strImageAttribution: { type: Sequelize.STRING(100), },
            dateModified: { type: Sequelize.DATE },
            createdAt: { allowNull: false, type: Sequelize.DATE },
            updatedAt: { allowNull: false, type: Sequelize.DATE },
        });
    },
};
