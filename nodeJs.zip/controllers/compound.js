const { resDocCreated, resServerError, resFound, resDocUpdated, resErrorOccured } = require("../services/response");
const db = require("../models")
let path = require("path");
const reader = require("xlsx");
const fs = require("fs");

const importspreadsheet = async (req, res) => {
    try {
        if (req.file == undefined) {
            return res.status(400).send("Please upload an excel file!");
        } else if (path.extname(req.file.originalname).includes(".xlsx") || path.extname(req.file.originalname).includes(".csv") || path.extname(req.file.originalname).includes(".xls")) {
            let filesname = req.file.filename;
            let url = path.join(__dirname, `../uploads/${filesname}`);
            const file = reader.readFile(url);
            const sheets = file.SheetNames;
            for (let i = 0; i < sheets.length; i++) {
                const temp = reader.utils.sheet_to_json(file.Sheets[file.SheetNames[i]], { raw: false });
                for (let doc of temp) {
                    let check = await db.compound.findOne({ where: { UUID: doc.id } });
                    if (check) await check.update(doc);
                    else {
                        let requestBody = {
                            UUID: doc.id,
                            compoundName: doc.CompoundName,
                            compoundDescription: doc.CompounrDescription,
                            strImageSource: doc.strImageSource,
                            strImageAttribution: doc.strImageAttribution ?? null,
                            dateModified: parseDate(doc.dateModified),
                        }
                        await db.compound.create(requestBody)
                    }
                }
            };
            unlinkExcel(url);
            return resDocCreated(res, 'Compounds Added');
        } else {
            return resErrorOccured(res, "Please upload only excel file.")
        }
    } catch (error) {
        return resServerError(res, error)
    }
}

let unlinkExcel = (filePath) => {
    setTimeout(() => {
        fs.unlink(filePath, (err) => {
            if (err) console.log(err);
        });
    }, 500);
};

function parseDate(date) {
    let cDate = String(date).split("/");
    let [getMonth, getDate, getYear] = [cDate[0], cDate[1], cDate[2]]
    getYear = `20` + getYear;
    let dateModified = new Date(`${getYear}-${getMonth}-${getDate}`);
    return dateModified
}

const getAll = async (req,res) =>{
    try {
        let data = await db.compound.findAll({});
        return resFound(res, data)
    } catch (error) {
        return resServerError(res, error);   
    }
}

const update = async (req,res) =>{
    try {
        let doc = await db.compound.update(req.body, {
            where : {
                Id:  req.query.id
            }
        });

        if(doc[0] == 1) return resDocUpdated(res, 'Compound Updated')

        else return resErrorOccured(res, "Something went wrong");
    } catch (error) {
        return resServerError(res, error);   
    }
}

module.exports = {
    importspreadsheet,
    update,
    getAll
}
