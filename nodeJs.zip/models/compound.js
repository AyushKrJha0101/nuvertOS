"use strict";
const { Model } = require("sequelize");
const { genrateUUI } = require("../services/generateUniqueId");

module.exports = (sequelize, DataTypes) => {
    class compound extends Model {

        static associate(models) {

        }
    }
    compound.init(
        {
            Id: {
                type: DataTypes.STRING(15),
                allowNull: false,
                defaultValue: () => {
                    const randomId = genrateUUI();
                    return randomId;
                },
                primaryKey: true,
            },
            UUID: { type: DataTypes.INTEGER },
            compoundName: { type: DataTypes.STRING(50) },
            compoundDescription: { type: DataTypes.STRING(300) },
            strImageSource: { type: DataTypes.STRING(100), allowNull: true },
            strImageAttribution: { type: DataTypes.STRING(100), allowNull: true },
            dateModified: {
                type: DataTypes.DATE, defaultValue: () => {
                    return new Date();
                }
            },
            createdAt: { allowNull: false, type: DataTypes.DATE },
            updatedAt: { allowNull: false, type: DataTypes.DATE },
        },
        {
            sequelize,
            tableName: "compound",
            modelName: "compound",
        }
    );
    return compound;
};
